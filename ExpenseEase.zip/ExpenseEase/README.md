# ExpenseEase

A simple expense tracker mobile app built with **React Native (Expo)**.
Tiny Project for **Cross Platform Development (CPD)** - BCA Honors, Division F, Parul University.

## Features
- Add, edit and delete expenses (title, amount, category)
- Live **total spent** on the home screen
- **Summary** tab showing spending per category with percentage bars
- Data saved on the device with AsyncStorage (works offline, survives app restarts)
- Input validation and delete confirmation

## Tech Stack
| Area | Tool |
|------|------|
| Framework | React Native + Expo (SDK 57) |
| Navigation | React Navigation (bottom tabs + native stack) |
| State | React Context API |
| Storage | @react-native-async-storage/async-storage |
| Language | JavaScript (ES6+) |

## Project Structure
```
ExpenseEase/
├── App.js                     # Root: providers + navigator
├── index.js                   # Expo entry point
├── app.json                   # Expo config
├── assets/                    # Icons and splash
└── src/
    ├── components/ExpenseItem.js
    ├── constants/             # theme.js, categories.js
    ├── context/ExpenseContext.js   # State + persistence
    ├── navigation/AppNavigator.js
    ├── screens/               # HomeScreen, AddExpenseScreen, SummaryScreen
    └── utils/format.js
```

## Getting Started
Requirements: Node.js 18+, and the **Expo Go** app on your phone (or an Android emulator).

```bash
git clone https://github.com/speedprav/ExpenseEase.git
cd ExpenseEase
npm install
npx expo start
```
Scan the QR code with Expo Go (Android) or the Camera app (iOS). Press `a` to open an Android emulator.

## Team
| Name | Enrollment No. |
|------|----------------|
| Pravinkumar Choudhary | 2305101270266 |
| Anurag Kumar | 2305101270020 |
| Anurag Pareekh | 2305101270021 |

## Future Scope
Date filters, monthly budgets, charts, export to CSV, cloud sync.
