import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEY = '@expenseease/expenses';
const ExpenseContext = createContext(null);

export function ExpenseProvider({ children }) {
  const [expenses, setExpenses] = useState([]);
  const [loaded, setLoaded] = useState(false);

  // Load saved expenses once on start
  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw) setExpenses(JSON.parse(raw));
      } catch (e) {
        console.warn('Failed to load expenses', e);
      } finally {
        setLoaded(true);
      }
    })();
  }, []);

  // Persist on every change (after the initial load)
  useEffect(() => {
    if (!loaded) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(expenses)).catch((e) =>
      console.warn('Failed to save expenses', e)
    );
  }, [expenses, loaded]);

  const addExpense = ({ title, amount, category }) =>
    setExpenses((prev) => [
      { id: Date.now().toString(), title, amount: Number(amount), category, date: new Date().toISOString() },
      ...prev,
    ]);

  const updateExpense = (id, changes) =>
    setExpenses((prev) =>
      prev.map((e) => (e.id === id ? { ...e, ...changes, amount: Number(changes.amount) } : e))
    );

  const deleteExpense = (id) => setExpenses((prev) => prev.filter((e) => e.id !== id));

  const total = useMemo(() => expenses.reduce((s, e) => s + e.amount, 0), [expenses]);

  const value = { expenses, total, loaded, addExpense, updateExpense, deleteExpense };
  return <ExpenseContext.Provider value={value}>{children}</ExpenseContext.Provider>;
}

export const useExpenses = () => {
  const ctx = useContext(ExpenseContext);
  if (!ctx) throw new Error('useExpenses must be used inside ExpenseProvider');
  return ctx;
};
