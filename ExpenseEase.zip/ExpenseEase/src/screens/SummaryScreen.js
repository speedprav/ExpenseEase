import React, { useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { useExpenses } from '../context/ExpenseContext';
import { CATEGORIES } from '../constants/categories';
import { colors } from '../constants/theme';
import { formatAmount } from '../utils/format';

export default function SummaryScreen() {
  const { expenses, total } = useExpenses();

  const rows = useMemo(
    () =>
      CATEGORIES.map((c) => ({
        category: c,
        sum: expenses.filter((e) => e.category === c).reduce((s, e) => s + e.amount, 0),
      })).sort((a, b) => b.sum - a.sum),
    [expenses]
  );

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.heading}>Spending by Category</Text>
      {rows.map(({ category, sum }) => {
        const pct = total ? (sum / total) * 100 : 0;
        return (
          <View key={category} style={styles.row}>
            <View style={styles.rowTop}>
              <Text style={styles.cat}>{category}</Text>
              <Text style={styles.sum}>
                {formatAmount(sum)} ({pct.toFixed(0)}%)
              </Text>
            </View>
            <View style={styles.track}>
              <View style={[styles.fill, { width: `${pct}%` }]} />
            </View>
          </View>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 16 },
  heading: { fontSize: 18, fontWeight: '700', color: colors.text, marginBottom: 16 },
  row: { marginBottom: 16 },
  rowTop: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  cat: { fontSize: 15, color: colors.text, fontWeight: '600' },
  sum: { fontSize: 14, color: colors.muted },
  track: { height: 10, backgroundColor: colors.border, borderRadius: 5, overflow: 'hidden' },
  fill: { height: 10, backgroundColor: colors.accent, borderRadius: 5 },
});
