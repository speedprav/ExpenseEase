import React from 'react';
import { View, Text, FlatList, StyleSheet, Alert, TouchableOpacity } from 'react-native';
import { useExpenses } from '../context/ExpenseContext';
import ExpenseItem from '../components/ExpenseItem';
import { colors } from '../constants/theme';
import { formatAmount } from '../utils/format';

export default function HomeScreen({ navigation }) {
  const { expenses, total, deleteExpense } = useExpenses();

  const confirmDelete = (item) =>
    Alert.alert('Delete expense', `Remove "${item.title}"?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => deleteExpense(item.id) },
    ]);

  return (
    <View style={styles.container}>
      <View style={styles.totalCard}>
        <Text style={styles.totalLabel}>Total Spent</Text>
        <Text style={styles.totalValue}>{formatAmount(total)}</Text>
      </View>

      <FlatList
        data={expenses}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <ExpenseItem
            item={item}
            onPress={() => navigation.navigate('AddExpense', { expense: item })}
            onDelete={() => confirmDelete(item)}
          />
        )}
        contentContainerStyle={expenses.length ? styles.list : styles.emptyWrap}
        ListEmptyComponent={<Text style={styles.empty}>No expenses yet. Tap + to add one.</Text>}
      />

      <TouchableOpacity style={styles.fab} onPress={() => navigation.navigate('AddExpense')}>
        <Text style={styles.fabText}>+</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  totalCard: {
    backgroundColor: colors.primary,
    margin: 16,
    padding: 20,
    borderRadius: 16,
  },
  totalLabel: { color: '#cfd9ea', fontSize: 13 },
  totalValue: { color: '#fff', fontSize: 30, fontWeight: '800', marginTop: 4 },
  list: { paddingHorizontal: 16, paddingBottom: 100 },
  emptyWrap: { flexGrow: 1, justifyContent: 'center' },
  empty: { textAlign: 'center', color: colors.muted },
  fab: {
    position: 'absolute',
    right: 20,
    bottom: 24,
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
  },
  fabText: { color: '#fff', fontSize: 30, lineHeight: 34 },
});
