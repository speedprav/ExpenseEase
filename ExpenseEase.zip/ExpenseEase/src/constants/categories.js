export const CATEGORIES = ['Food', 'Travel', 'Shopping', 'Bills', 'Health', 'Other'];
