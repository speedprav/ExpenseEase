export const colors = {
  primary: '#1a3c6e',
  accent: '#2e7d5b',
  danger: '#c0392b',
  background: '#f4f6fa',
  card: '#ffffff',
  text: '#1c1c1e',
  muted: '#6b7280',
  border: '#e2e6ee',
};
